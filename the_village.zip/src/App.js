import React from 'react';

function App() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>Welcome to The Village</h1>
      <p>This is a simple React app deployed via GitHub & Vercel.</p>
    </div>
  );
}

export default App;
